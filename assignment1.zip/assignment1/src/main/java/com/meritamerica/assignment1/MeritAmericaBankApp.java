/** This is the main interface of MeritAmericaBank.
 * 
 * Name:  Djeme Doli & Tian Boothe
 * Date: 03/01/2021
 */
package com.meritamerica.assignment1;

public class MeritAmericaBankApp {
	
	public static void main(String[] args) {
		 	
		AccountHolder accountNumber = new AccountHolder("Djeme", "D", "Doli","123-456-7890", 100.0, 1000.0);
		String str = accountNumber.toString();
		System.out.println(str);
		
		/* ** Deposit and withdraw operations ****/
		double amount = -500.0;
		System.out.println("Deposit into Checking Account: "+amount);
		boolean deposit = accountNumber.Checking.deposit(amount);
		
		/* *** Withdraw 800 from Savings ***/
		boolean withdraw = accountNumber.Savings.withdraw(800);
		
		/* Display Checking account*****/
		String str3 = accountNumber.Checking.toString();
		System.out.println(str3);
		
		/* Display Savings account*****/
		String str4 = accountNumber.Savings.toString();
		System.out.println(str4);
		
		/* ******* A Second Account Holder *******/
		System.out.println("\n\n");
		AccountHolder accountNumber2 = new AccountHolder("Tian", "T", "Boothe","321-654-0987", 200.0, 500.0);
		String STR = accountNumber2.toString();
		System.out.println(STR);
		boolean deposit2 = accountNumber2.Checking.deposit(-500);
		boolean withdrawal2 = accountNumber2.Savings.withdraw(600);
		String STR4 = accountNumber2.toString();
		System.out.println(STR4);
		


		
		
		
	}
	
}