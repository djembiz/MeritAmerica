package com.meritamerica.assignment1;

public class SavingsAccount {
	
/* Constructors *******/
public SavingsAccount() {
}
public SavingsAccount(double opening_Balance) {
		  savingsBalance = opening_Balance;
	}
/* ****** CONSTANTS and INSTANCE VARIABLES*******/
private double savingsBalance;
private static final double INTEREST_RATE = 0.01;
	
/* ******** METHODS **********/ 
/* ** Setter and Getter **/
public void setSavingsBalance(double Balance) { this.savingsBalance = Balance;}
public double getBalance(){ return savingsBalance;}
/* *****************************/

boolean deposit(double amount) {
	if (amount >0) {
	   savingsBalance +=amount;
	return true;}
	else {
		System.out.println("Cannot deposit Negative amount");
		return false;
	}
		
   }

boolean withdraw(double amount) {
	if(amount>0 && amount< savingsBalance) {
	  savingsBalance -= amount;
	  return true;}
	else {
		System.out.println("Unsufficient funds or Negative amount");
		return false;}
	}
double getInterestRate() {return INTEREST_RATE;}
	
double futureValue(int years){
		double FV = savingsBalance * Math.pow((1 + INTEREST_RATE), years);
		return FV;
		}
public String toString() {
	return "Savings Account Balance: $" + getBalance() +
			"\nSavings Account Interest Rate: " +INTEREST_RATE +
			"\nSavings Account Balance in 3 years: " +futureValue(3);		
	}	
}